const fontFamily = {
  appTextBold: 'NunitoSans-Bold',
  appTextExtraBold: 'NunitoSans-ExtraBold',
  appTextItalic: 'NunitoSans-Italic',
  appTextLight: 'NunitoSans-Light',
  appTextRegular: 'NunitoSans-Regular',
  appTextSemiBold: 'NunitoSans-SemiBold',
}

export { fontFamily }

