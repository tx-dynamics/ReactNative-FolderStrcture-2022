export const BASE_URL = ''
export const IMAGE_BASE_URL = ''

export const api = {

}
