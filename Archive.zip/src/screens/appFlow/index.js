import Dashboard from './dashboard'
import Profile from './profile'
import Favorite from './favorite'
import DrawerScreen from './drawerScreen'

export {
    Dashboard, Profile, Favorite, DrawerScreen
}
